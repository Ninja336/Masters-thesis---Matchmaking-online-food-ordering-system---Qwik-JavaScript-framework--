import { component$ } from '@builder.io/qwik';
import './Sidebar.css';
import { assets } from '../../assets/assets';

export const Sidebar = component$(() => {
  return (
    <div class="sidebar">
      <div class="sidebar-options">
        <a href="/Add/" class="sidebar-option">
          <img src={assets.add_icon} alt="Add Items" />
          <p>Add Items</p>
        </a>
        <a href="/List/" class="sidebar-option">
          <img src={assets.order_icon} alt="List Items" />
          <p>List Items</p>
        </a>
        <a href="/Orders/" class="sidebar-option">
          <img src={assets.order_icon} alt="Orders" />
          <p>Orders</p>
        </a>
      </div>
    </div>
  );
});

export default Sidebar;
