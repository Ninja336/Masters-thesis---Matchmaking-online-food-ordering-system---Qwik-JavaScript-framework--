
import ImgProfileImage from '~/assets/profile_image.png?jsx';
import ImgLogo from '~/assets/logo.png?jsx';import { component$ } from '@builder.io/qwik';
import './Navbar.css';
import { assets } from '../../assets/assets';

export const Navbar = component$(() => {
  return (
    <div class="navbar">
      <ImgLogo class="logo" alt="Logo" />
      <ImgProfileImage class="profile" alt="Profile" />
    </div>
  );
});

export default Navbar;
