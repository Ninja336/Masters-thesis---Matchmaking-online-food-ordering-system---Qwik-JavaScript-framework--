import { component$, useVisibleTask$, useStore, $ } from '@builder.io/qwik';
import './style.css';
import { url, currency } from '../../assets/assets';
import axios from 'axios';
import { toast } from 'react-toastify';

// Define the type for food items
interface FoodItem {
  _id: string;
  name: string;
  category: string;
  price: number;
  image: string;
}

// Convert the component to a Qwik component
const List = component$(() => {
  // Use Qwik's store for state management
  const store = useStore<{ list: FoodItem[] }>({ list: [] });

  // Fetch the list of food items
  const fetchList = $(async () => {
    try {
      const response = await axios.get(`${url}/api/food/list`);
      if (response.data.success) {
        store.list = response.data.data;
      } else {
        toast.error('Error');
      }
    } catch (error) {
      toast.error('Failed to fetch list');
    }
  });

  // Remove a food item
  const removeFood = $(async (foodId: string) => {
    try {
      const response = await axios.post(`${url}/api/food/remove`, {
        id: foodId,
      });
      if (response.data.success) {
        toast.success(response.data.message);
        fetchList();
      } else {
        toast.error('Error');
      }
    } catch (error) {
      toast.error('Failed to remove food item');
    }
  });

  // Qwik's way to run a function when the component becomes visible
  useVisibleTask$(() => {
    fetchList();
  });

  return (
    <div class="list add flex-col">
      <p>All Foods List</p>
      <div class="list-table">
        <div class="list-table-format title">
          <b>Image</b>
          <b>Name</b>
          <b>Category</b>
          <b>Price</b>
          <b>Action</b>
        </div>
        {store.list.map((item, index) => (
          <div key={index} class="list-table-format">
            <img src={`${url}/images/${item.image}`} alt="" />
            <p>{item.name}</p>
            <p>{item.category}</p>
            <p>
              {currency}
              {item.price}
            </p>
            <p class="cursor" onClick$={() => removeFood(item._id)}>
              x
            </p>
          </div>
        ))}
      </div>
    </div>
  );
});

export default List;
