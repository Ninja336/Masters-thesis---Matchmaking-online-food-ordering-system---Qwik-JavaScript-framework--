import { component$ } from '@builder.io/qwik';
import Navbar from '../components/Navbar/Navbar';
import Sidebar from '../components/Sidebar/Sidebar';

export default component$(() => {
  return (
    <div class='app'>
      <Navbar />
      <hr />
      <div class='app-content'>
        <Sidebar />
        <div>
          {/* Content for the route will be rendered here */}
        </div>
      </div>
    </div>
  );
});
