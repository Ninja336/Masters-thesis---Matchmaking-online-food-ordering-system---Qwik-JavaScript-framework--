import { component$, useVisibleTask$, useStore, $ } from '@builder.io/qwik';
import './style.css';
import { toast } from 'react-toastify';
import axios from 'axios';
import { assets, url, currency } from '../../assets/assets';

// Define types for the order and item data
interface OrderItem {
  name: string;
  quantity: number;
}

interface Address {
  firstName: string;
  lastName: string;
  street: string;
  city: string;
  state: string;
  country: string;
  zipcode: string;
  phone: string;
}

interface Order {
  _id: string;
  items: OrderItem[];
  address: Address;
  amount: number;
  status: string;
}

// Convert the component to a Qwik component
const Order = component$(() => {
  // Use Qwik's store for state management
  const store = useStore<{ orders: Order[] }>({ orders: [] });

  // Fetch all orders
  const fetchAllOrders = $(async () => {
    try {
      const response = await axios.get(`${url}/api/order/list`);
      if (response.data.success) {
        store.orders = response.data.data.reverse();
      } else {
        toast.error('Error');
      }
    } catch (error) {
      toast.error('Failed to fetch orders');
    }
  });

  // Handle order status change
  const statusHandler = $(async (event: Event, orderId: string) => {
    const target = event.target as HTMLSelectElement;
    const status = target.value;

    try {
      const response = await axios.post(`${url}/api/order/status`, {
        orderId,
        status,
      });
      if (response.data.success) {
        await fetchAllOrders();
      }
    } catch (error) {
      toast.error('Failed to update order status');
    }
  });

  // Qwik's way to run a function when the component becomes visible
  useVisibleTask$(() => {
    fetchAllOrders();
  });

  return (
    <div class="order add">
      <h3>Order Page</h3>
      <div class="order-list">
        {store.orders.map((order, index) => (
          <div key={index} class="order-item">
            <img src={assets.parcel_icon} alt="" />
            <div>
              <p class="order-item-food">
                {order.items.map((item, index) =>
                  index === order.items.length - 1
                    ? `${item.name} x ${item.quantity}`
                    : `${item.name} x ${item.quantity}, `
                )}
              </p>
              <p class="order-item-name">
                {order.address.firstName} {order.address.lastName}
              </p>
              <div class="order-item-address">
                <p>{order.address.street},</p>
                <p>
                  {order.address.city}, {order.address.state},{' '}
                  {order.address.country}, {order.address.zipcode}
                </p>
              </div>
              <p class="order-item-phone">{order.address.phone}</p>
            </div>
            <p>Items: {order.items.length}</p>
            <p>
              {currency}
              {order.amount}
            </p>
            <select
              onChange$={(e) => statusHandler(e, order._id)}
              value={order.status}
            >
              <option value="Food Processing">Food Processing</option>
              <option value="Out for delivery">Out for delivery</option>
              <option value="Delivered">Delivered</option>
            </select>
          </div>
        ))}
      </div>
    </div>
  );
});

export default Order;
