import { component$, $, useStore } from '@builder.io/qwik';
import './Add.css';
import { assets, url } from '../../assets/assets';
import axios from 'axios';
import { toast } from 'react-toastify';

// Define the data structure using TypeScript types
interface ProductData {
  name: string;
  description: string;
  price: string;
  category: string;
}

// Convert the component to a Qwik component
const Add = component$(() => {
  // Use Qwik's store for state management
  const data = useStore<ProductData>({
    name: '',
    description: '',
    price: '',
    category: 'Salad',
  });

  // Use Qwik's store for managing the image state
  const image = useStore<{ value: File | null }>({ value: null });

  // Define the onSubmit handler
  const onSubmitHandler = $(async (event: Event) => {
    event.preventDefault();

    if (!image.value) {
      toast.error('Image not selected');
      return;
    }

    const formData = new FormData();
    formData.append('name', data.name);
    formData.append('description', data.description);
    formData.append('price', String(Number(data.price)));
    formData.append('category', data.category);
    formData.append('image', image.value);

    try {
      const response = await axios.post(`${url}/api/food/add`, formData);

      if (response.data.success) {
        toast.success(response.data.message);
        data.name = '';
        data.description = '';
        data.price = '';
        image.value = null;
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      toast.error('Failed to submit data');
    }
  });

  // Define the onChange handler
  const onChangeHandler = $((event: Event) => {
    const target = event.target as HTMLInputElement;
    const { name, value } = target;
    (data as any)[name] = value;
  });

  // Handle image change
  const onImageChangeHandler = $((event: Event) => {
    const target = event.target as HTMLInputElement;
    if (target.files && target.files[0]) {
      image.value = target.files[0];
    }
    target.value = '';
  });

  return (
    <div class="add">
      <form class="flex-col" preventdefault:submit onSubmit$={onSubmitHandler}>
        <div class="add-img-upload flex-col">
          <p>Upload image</p>
          <input
            type="file"
            accept="image/*"
            id="image"
            hidden
            onChange$={onImageChangeHandler}
          />
          <label for="image">
            <img
              src={!image.value ? assets.upload_area : URL.createObjectURL(image.value)}
              alt=""
            />
          </label>
        </div>
        <div class="add-product-name flex-col">
          <p>Product name</p>
          <input
            name="name"
            type="text"
            placeholder="Type here"
            required
            value={data.name}
            onInput$={onChangeHandler}
          />
        </div>
        <div class="add-product-description flex-col">
          <p>Product description</p>
          <textarea
            name="description"
            rows={6}
            placeholder="Write content here"
            required
            value={data.description}
            onInput$={onChangeHandler}
          />
        </div>
        <div class="add-category-price">
          <div class="add-category flex-col">
            <p>Product category</p>
            <select name="category" onInput$={onChangeHandler}>
              <option value="Salad">Salad</option>
              <option value="Rolls">Rolls</option>
              <option value="Deserts">Deserts</option>
              <option value="Sandwich">Sandwich</option>
              <option value="Cake">Cake</option>
              <option value="Pure Veg">Pure Veg</option>
              <option value="Pasta">Pasta</option>
              <option value="Noodles">Noodles</option>
            </select>
          </div>
          <div class="add-price flex-col">
            <p>Product Price</p>
            <input
              type="number"
              name="price"
              placeholder="25"
              value={data.price}
              onInput$={onChangeHandler}
            />
          </div>
        </div>
        <button type="submit" className="add-btn">
          ADD
        </button>
      </form>
    </div>
  );
});

export default Add;
