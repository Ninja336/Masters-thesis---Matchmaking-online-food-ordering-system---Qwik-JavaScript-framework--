import { component$, useContext, useStore, useTask$ } from '@builder.io/qwik';
import './PlaceOrder.css';
import { StoreContext } from '../../context/StoreContext'; // Ensure casing is correct
import { assets } from '../../assets/assets'; // Ensure assets are imported correctly
import { toast } from 'react-toastify';
import axios from 'axios';

interface OrderData {
  firstName: string;
  lastName: string;
  email: string;
  street: string;
  city: string;
  state: string;
  zipcode: string;
  country: string;
  phone: string;
}

export default component$(() => {
  const store = useStore<{ payment: string; data: OrderData }>({
    payment: 'cod',
    data: {
      firstName: '',
      lastName: '',
      email: '',
      street: '',
      city: '',
      state: '',
      zipcode: '',
      country: '',
      phone: '',
    },
  });

  const { getTotalCartAmount, token, food_list, cartItems, url, setCartItems, currency, deliveryCharge } = useContext(StoreContext);

  // Handling form data change
  const onChangeHandler$ = (event: Event) => {
    const target = event.target as HTMLInputElement;
    const name = target.name;
    const value = target.value;
    store.data[name as keyof OrderData] = value;
  };

  // Place Order Function
  const placeOrder$ = async (e: Event) => {
    e.preventDefault();
    const orderItems = food_list.filter((item: { _id: string | number; }) => cartItems[item._id] > 0).map((item) => ({
      ...item,
      quantity: cartItems[item._id],
    }));

    const orderData = {
      address: store.data,
      items: orderItems,
      amount: getTotalCartAmount() + deliveryCharge,
    };

    if (store.payment === 'stripe') {
      const response = await axios.post(`${url}/api/order/place`, orderData, { headers: { token } });
      if (response.data.success) {
        window.location.replace(response.data.session_url);
      } else {
        toast.error('Something Went Wrong');
      }
    } else {
      const response = await axios.post(`${url}/api/order/placecod`, orderData, { headers: { token } });
      if (response.data.success) {
        toast.success(response.data.message);
        setCartItems({});
        window.location.href = '/myorders';
      } else {
        toast.error('Something Went Wrong');
      }
    }
  };

  // Effect to check token and cart total
  useTask$(({ track }) => {
    track(() => token);
    if (!token) {
      toast.error('To place an order, sign in first');
      window.location.href = '/cart';
    } else if (getTotalCartAmount() === 0) {
      window.location.href = '/cart';
    }
  });

  return (
    <form onSubmit$={placeOrder$} className='place-order'>
      <div class="place-order-left">
        <p class="title">Delivery Information</p>
        <div class="multi-field">
          <input type="text" name="firstName" onChange$={onChangeHandler$} value={store.data.firstName} placeholder="First name" required />
          <input type="text" name="lastName" onChange$={onChangeHandler$} value={store.data.lastName} placeholder="Last name" required />
        </div>
        <input type="email" name="email" onChange$={onChangeHandler$} value={store.data.email} placeholder="Email address" required />
        <input type="text" name="street" onChange$={onChangeHandler$} value={store.data.street} placeholder="Street" required />
        <div class="multi-field">
          <input type="text" name="city" onChange$={onChangeHandler$} value={store.data.city} placeholder="City" required />
          <input type="text" name="state" onChange$={onChangeHandler$} value={store.data.state} placeholder="State" required />
        </div>
        <div class="multi-field">
          <input type="text" name="zipcode" onChange$={onChangeHandler$} value={store.data.zipcode} placeholder="Zip code" required />
          <input type="text" name="country" onChange$={onChangeHandler$} value={store.data.country} placeholder="Country" required />
        </div>
        <input type="text" name="phone" onChange$={onChangeHandler$} value={store.data.phone} placeholder="Phone" required />
      </div>
      <div class="place-order-right">
        <div class="cart-total">
          <h2>Cart Totals</h2>
          <div>
            <div class="cart-total-details">
              <p>Subtotal</p>
              <p>{currency}{getTotalCartAmount()}</p>
            </div>
            <hr />
            <div class="cart-total-details">
              <p>Delivery Fee</p>
              <p>{currency}{getTotalCartAmount() === 0 ? 0 : deliveryCharge}</p>
            </div>
            <hr />
            <div class="cart-total-details">
              <b>Total</b>
              <b>{currency}{getTotalCartAmount() === 0 ? 0 : getTotalCartAmount() + deliveryCharge}</b>
            </div>
          </div>
        </div>
        <div class="payment">
          <h2>Payment Method</h2>
          <div onClick$={() => (store.payment = 'cod')} class="payment-option">
            <img src={store.payment === 'cod' ? assets.checked : assets.un_checked} alt="COD" />
            <p>COD (Cash on Delivery)</p>
          </div>
          <div onClick$={() => (store.payment = 'stripe')} class="payment-option">
            <img src={store.payment === 'stripe' ? assets.checked : assets.un_checked} alt="Stripe" />
            <p>Stripe (Credit / Debit)</p>
          </div>
        </div>
        <button class="place-order-submit" type="submit">
          {store.payment === 'cod' ? 'Place Order' : 'Proceed To Payment'}
        </button>
      </div>
    </form>
  );
});
