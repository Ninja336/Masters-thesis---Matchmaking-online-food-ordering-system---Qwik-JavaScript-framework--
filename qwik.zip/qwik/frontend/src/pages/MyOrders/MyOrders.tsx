import { component$, useContext, useStore, useTask$ } from '@builder.io/qwik';
import './MyOrders.css';
import axios from 'axios';
import { StoreContext } from '../../context/StoreContext'; // Ensure casing matches all other imports
import { assets } from '../../assets/assets'; // Ensure assets is imported correctly

interface OrderItem {
  name: string;
  quantity: number;
}

interface Order {
  items: OrderItem[];
  amount: number;
  status: string;
}

export default component$(() => {
  // State store to hold the orders data
  const state = useStore<{ data: Order[] }>({ data: [] });
  const { url, token, currency } = useContext(StoreContext);

  // Fetch orders from the API
  const fetchOrders = async () => {
    try {
      const response = await axios.post(`${url}/api/order/userorders`, {}, {
        headers: { token }
      });
      state.data = response.data.data;
    } catch (error) {
      console.error('Error fetching orders:', error);
    }
  };

  // Effect-like task to fetch orders when the token changes
  useTask$(({ track }) => {
    track(() => token);
    if (token) {
      fetchOrders();
    }
  });

  return (
    <div class='my-orders'>
      <h2>My Orders</h2>
      <div class="container">
        {state.data.map((order, index) => (
          <div key={index} class='my-orders-order'>
            <img src={assets.parcel_icon} alt="Parcel Icon" />
            <p>
              {order.items.map((item, itemIndex) => (
                `${item.name} x ${item.quantity}${itemIndex === order.items.length - 1 ? '' : ', '}`
              ))}
            </p>
            <p>{currency}{order.amount}.00</p>
            <p>Items: {order.items.length}</p>
            <p><span>&#x25cf;</span> <b>{order.status}</b></p>
            <button onClick$={fetchOrders}>Track Order</button>
          </div>
        ))}
      </div>
    </div>
  );
});
