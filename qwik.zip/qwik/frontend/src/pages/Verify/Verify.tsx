import { component$, useContext, useStore, useTask$ } from '@builder.io/qwik';
import axios from 'axios';
import './Verify.css';
import { StoreContext } from '../../context/StoreContext'; // Ensure casing is correct

export default component$(() => {
  const { url } = useContext(StoreContext); // Access the store context
  const store = useStore({
    success: '',
    orderId: '',
  });

  // Function to get query parameters from URL
  const getQueryParams = () => {
    const searchParams = new URLSearchParams(window.location.search);
    store.success = searchParams.get('success') || '';
    store.orderId = searchParams.get('orderId') || '';
  };

  // Function to verify payment
  const verifyPayment = async () => {
    try {
      const response = await axios.post(`${url}/api/order/verify`, {
        success: store.success,
        orderId: store.orderId,
      });

      if (response.data.success) {
        window.location.href = '/myorders'; // Redirect to myorders page
      } else {
        window.location.href = '/'; // Redirect to home page
      }
    } catch (error) {
      console.error('Verification failed:', error);
      window.location.href = '/'; // Redirect to home on error
    }
  };

  // useTask$ runs when the component is rendered
  useTask$(() => {
    getQueryParams(); // Get the query parameters from the URL
    verifyPayment(); // Verify payment after retrieving query parameters
  });

  return (
    <div class="verify">
      <div class="spinner"></div>
    </div>
  );
});
