import { component$, useStore } from '@builder.io/qwik';
import Header from '../components/Header/Header';
import ExploreMenu from '../components/ExploreMenu/ExploreMenu';
import FoodDisplay from '../components/FoodDisplay/FoodDisplay';

interface CategoryStore {
  category: string;
}

export default component$(() => {
  const categoryStore = useStore<CategoryStore>({ category: 'All' });

  return (
    <>
      <Header />
      <ExploreMenu 
        setCategory={(newCategory: string) => categoryStore.category = newCategory} // Rename to 'setCategory'
        category={categoryStore.category} 
      />
      <FoodDisplay category={categoryStore.category} />
    </>
  );
});

