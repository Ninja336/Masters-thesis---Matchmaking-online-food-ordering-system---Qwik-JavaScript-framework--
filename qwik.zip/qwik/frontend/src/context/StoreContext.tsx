import { component$, createContextId, useContextProvider, useStore, useTask$ } from '@builder.io/qwik';
import axios from 'axios';
import { food_list, menu_list } from "../assets/assets";

// Define the structure of a food item with all necessary properties
interface FoodItem {
  _id: string;
  name: string;
  price: number;
  image: string;
  description: string;
  category: string;
}

// Define the structure of a menu item
interface MenuItem {
  menu_name: string;
  menu_image: string;
}

// Define the type for StoreContext
export interface StoreContextType {
  url: string;
  food_list: FoodItem[];
  cartItems: Record<string, number>;
  addToCart: (itemId: string) => Promise<void>;
  removeFromCart: (itemId: string) => Promise<void>;
  getTotalCartAmount: () => number;
  token: string;
  setToken: (token: string) => void;
  loadCartData: (token: string) => Promise<void>;
  setCartItems: (cartItems: Record<string, number>) => void;
  currency: string;
  deliveryCharge: number;
  menu_list: MenuItem[]; // Added menu_list property
}

// Create a context for the store
export const StoreContext = createContextId<StoreContextType>('store-context');

// Define the StoreContextProvider component
export const StoreContextProvider = component$((props: { children?: any }) => {
  const url = 'http://localhost:4000';
  const currency = '$';
  const deliveryCharge = 5;

  // Use Qwik's useStore to manage reactive state
  const store = useStore<StoreContextType>({
    food_list: [],
    cartItems: {},
    token: '',
    menu_list: [
      { menu_name: 'Burgers', menu_image: '/images/burgers.png' },
      { menu_name: 'Pizzas', menu_image: '/images/pizzas.png' },
      // Add more menu items here
    ],
    url,
    currency,
    deliveryCharge,
    addToCart: async (itemId: string) => {
      if (!store.cartItems[itemId]) {
        store.cartItems[itemId] = 1;
      } else {
        store.cartItems[itemId] += 1;
      }
      if (store.token) {
        await axios.post(url + '/api/cart/add', { itemId }, { headers: { token: store.token } });
      }
    },
    removeFromCart: async (itemId: string) => {
      if (store.cartItems[itemId] > 1) {
        store.cartItems[itemId] -= 1;
      } else {
        delete store.cartItems[itemId];
      }
      if (store.token) {
        await axios.post(url + '/api/cart/remove', { itemId }, { headers: { token: store.token } });
      }
    },
    getTotalCartAmount: () => {
      let totalAmount = 0;
      for (const itemId in store.cartItems) {
        const itemInfo = store.food_list.find((item: FoodItem) => item._id === itemId);
        if (itemInfo) {
          totalAmount += itemInfo.price * store.cartItems[itemId];
        }
      }
      return totalAmount;
    },
    setToken: (token: string) => {
      store.token = token;
    },
    loadCartData: async (token: string) => {
      const response = await axios.post(url + '/api/cart/get', {}, { headers: { token } });
      store.cartItems = response.data.cartData;
    },
    setCartItems: (cartItems: Record<string, number>) => {
      store.cartItems = cartItems;
    },
  });

  // Fetch food list from API
  const fetchFoodList = async () => {
    const response = await axios.get(url + '/api/food/list');
    
    // Ensure the response data is correctly mapped to the FoodItem structure
    store.food_list = response.data.data.map((item: any) => ({
      _id: item._id,
      name: item.name,
      price: item.price,
      image: item.image,
      description: item.description,
      category: item.category,
    }));
  };

  // Load data on component mount
  useTask$(async () => {
    await fetchFoodList();
    const token = localStorage.getItem('token');
    if (token) {
      store.token = token;
      await store.loadCartData(token);
    }
  });

  // Provide the context value to children components
  useContextProvider(StoreContext, store);

  return <>{props.children}</>;
});
