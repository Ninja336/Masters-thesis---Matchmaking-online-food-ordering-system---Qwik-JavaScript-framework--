import { component$, useContext } from '@builder.io/qwik'; // Updated to use `useContext`
import FoodItem from '../FoodItem/FoodItem';
import { StoreContext } from '../../context/StoreContext';
import './FoodDisplay.css';

interface FoodDisplayProps {
  category: string;
}

// Define the item type
interface FoodItemType {
  _id: string;
  image: string;
  name: string;
  description: string;
  price: number;
  category: string;
}

const FoodDisplay = component$<FoodDisplayProps>(({ category }) => {
  const store = useContext(StoreContext); // Correct hook to consume the context

  return (
    <div class='food-display' id='food-display'>
      <h2>Top dishes near you</h2>
      <div class='food-display-list'>
        {store.food_list.map((item: FoodItemType) => { // Explicitly type `item`
          if (category === 'All' || category === item.category) {
            return (
              <FoodItem
                key={item._id}
                image={item.image}
                name={item.name}
                desc={item.description}
                price={item.price}
                id={item._id}
              />
            );
          }
          return null; // Ensure to return something when condition fails
        })}
      </div>
    </div>
  );
});

export default FoodDisplay;
