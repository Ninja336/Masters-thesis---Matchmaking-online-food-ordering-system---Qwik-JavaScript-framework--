import { component$, useContext, useStore, $ } from '@builder.io/qwik';
import './LoginPopup.css';
import { assets } from '../../assets/assets';
import { StoreContext } from '../../context/StoreContext';
import axios from 'axios';
import { toast } from 'react-toastify';

interface LoginPopupProps {
  setShowLogin: (show: boolean) => void;
}

const LoginPopup = component$((props: LoginPopupProps) => {
  const { setToken, url, loadCartData } = useContext(StoreContext);
  const state = useStore({
    currState: "Sign Up",
    data: {
      name: "",
      email: "",
      password: ""
    }
  });

  const onChangeHandler = $((event: Event) => {
    const input = event.target as HTMLInputElement;
    const name = input.name;
    const value = input.value;
    state.data = { ...state.data, [name]: value };
  });

  const onLogin = $(async (e: Event) => {
    e.preventDefault();
  
    let new_url = url;
    if (state.currState === "Login") {
      new_url += "/api/user/login";
    } else {
      new_url += "/api/user/register";
    }
  
    try {
      const response = await axios.post(new_url, state.data);
      if (response.data.success) {
        setToken(response.data.token);
        localStorage.setItem("token", response.data.token);
        loadCartData(response.data.token); // Pass token as string
        props.setShowLogin(false);
      } else {
        toast.error(response.data.message);
      }
    } catch (error) {
      toast.error("An error occurred. Please try again.");
    }
  });
  

  return (
    <div class='login-popup'>
      <form onSubmit$={onLogin} class="login-popup-container">
        <div class="login-popup-title">
          <h2>{state.currState}</h2>
          <img onClick$={() => props.setShowLogin(false)} src={assets.cross_icon} alt="Close" />
        </div>
        <div class="login-popup-inputs">
          {state.currState === "Sign Up" && (
            <input
              name='name'
              onInput$={onChangeHandler}
              value={state.data.name}
              type="text"
              placeholder='Your name'
              required
            />
          )}
          <input
            name='email'
            onInput$={onChangeHandler}
            value={state.data.email}
            type="email"
            placeholder='Your email'
          />
          <input
            name='password'
            onInput$={onChangeHandler}
            value={state.data.password}
            type="password"
            placeholder='Password'
            required
          />
        </div>
        <button>{state.currState === "Login" ? "Login" : "Create account"}</button>
        <div class="login-popup-condition">
          <input type="checkbox" id="terms" required />
          <p>By continuing, I agree to the terms of use & privacy policy.</p>
        </div>
        {state.currState === "Login"
          ? <p>Create a new account? <span onClick$={() => state.currState = 'Sign Up'}>Click here</span></p>
          : <p>Already have an account? <span onClick$={() => state.currState = 'Login'}>Login here</span></p>
        }
      </form>
    </div>
  );
});

export default LoginPopup;