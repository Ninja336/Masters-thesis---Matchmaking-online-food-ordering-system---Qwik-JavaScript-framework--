import { component$, useContext, useStore, $ } from '@builder.io/qwik';
import './FoodItem.css';
import { assets } from '../../assets/assets'; // Ensure this path is correct
import { StoreContext } from '../../context/StoreContext'; // Ensure this path is correct

// Define the type for the context value if not exported
interface StoreContextType {
  cartItems: Record<string, number>;
  addToCart: (id: string) => void;
  removeFromCart: (id: string) => void;
  url: string;
  currency: string;
}

// Define the props for the FoodItem component
interface FoodItemProps {
  image: string;
  name: string;
  price: number;
  desc: string;
  id: string;
}

// Qwik component
const FoodItem = component$((props: FoodItemProps) => {
  // Access the StoreContext
  const context = useContext(StoreContext);
  if (!context) {
    return <div>Loading...</div>;
  }

  // Type assertion to ensure context is of the expected type
  const { cartItems, addToCart, removeFromCart, url, currency } = context as StoreContextType;

  // Use Qwik's store for local component state
  const state = useStore({ itemCount: 0 });

  // Event handlers
  const handleAddToCart = $(() => {
    addToCart(props.id);
    state.itemCount += 1; // Update local count
  });

  const handleRemoveFromCart = $(() => {
    removeFromCart(props.id);
    if (state.itemCount > 0) {
      state.itemCount -= 1; // Update local count
    }
  });

  return (
    <div class='food-item'>
      <div class='food-item-img-container'>
        <img class='food-item-image' src={`${url}/images/${props.image}`} alt={props.name} />
        {!cartItems[props.id]
          ? <img class='add' onClick$={handleAddToCart} src={assets.add_icon_white} alt="Add to cart" />
          : <div class="food-item-counter">
              <img src={assets.remove_icon_red} onClick$={handleRemoveFromCart} alt="Remove from cart" />
              <p>{cartItems[props.id]}</p>
              <img src={assets.add_icon_green} onClick$={handleAddToCart} alt="Add more" />
            </div>
        }
      </div>
      <div class="food-item-info">
        <div class="food-item-name-rating">
          <p>{props.name}</p> <img src={assets.rating_starts} alt="Rating stars" />
        </div>
        <p class="food-item-desc">{props.desc}</p>
        <p class="food-item-price">{currency}{props.price}</p>
      </div>
    </div>
  );
});

export default FoodItem;
