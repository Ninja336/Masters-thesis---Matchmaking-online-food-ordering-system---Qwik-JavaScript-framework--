import { component$, useContext, $ } from '@builder.io/qwik';
import './ExploreMenu.css';
import { StoreContext } from '../../context/StoreContext'; // Updated import path

// Define the props for the ExploreMenu component
interface ExploreMenuProps {
  category: string;
  setCategory: (value: string) => void;
}

// Define the type for the menu item
interface MenuItem {
  menu_name: string;
  menu_image: string;
}

// Qwik component
const ExploreMenu = component$((props: ExploreMenuProps) => {
  // Get the context and handle undefined case
  const context = useContext(StoreContext);

  if (!context) {
    // Handle the case where context is not available
    return <div>Loading...</div>;
  }

  // Destructure menu_list with proper type assertion
  const { menu_list } = context as { menu_list: MenuItem[] };

  // Function to handle category change
  const handleCategoryChange = $( (itemName: string) => {
    // Compute the new category value
    const newCategory = (props.category === itemName ? 'All' : itemName);
    // Call setCategory with the new value
    props.setCategory(newCategory);
  });

  return (
    <div class="explore-menu" id="explore-menu">
      <h1>Explore our menu</h1>
      <p class="explore-menu-text">
        Choose from a diverse menu featuring a delectable array of dishes. Our mission is to satisfy your cravings and elevate your dining experience, one delicious meal at a time.
      </p>
      <div class="explore-menu-list">
        {menu_list.map((item: MenuItem, index: number) => {
          return (
            <div 
              onClick$={() => handleCategoryChange(item.menu_name)}
              key={index}
              class="explore-menu-list-item"
            >
              <img
                src={item.menu_image}
                class={props.category === item.menu_name ? 'active' : ''}
                alt=""
              />
              <p>{item.menu_name}</p>
            </div>
          );
        })}
      </div>
      <hr />
    </div>
  );
});

export default ExploreMenu;
