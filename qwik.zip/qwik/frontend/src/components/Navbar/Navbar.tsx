import { component$, useContext, useStore, $ } from '@builder.io/qwik';
import './Navbar.css';
import {assets} from '../../assets/assets'; // Adjusted import if default export
import { StoreContext } from '../../context/StoreContext';

interface NavbarProps {
  setShowLogin: (show: boolean) => void;
  navigateTo: (page: string) => void;
}

const Navbar = component$((props: NavbarProps) => {
  const { getTotalCartAmount, token, setToken } = useContext(StoreContext);
  const state = useStore({
    menu: "home"
  });

  const logout = $(() => {
    localStorage.removeItem("token");
    setToken("");
    window.location.href = '/'; // Direct navigation
  });

  return (
    <div class='navbar'>
      <a href='/' onClick$={() => props.navigateTo('/')}> {/* Update navigation */}
        <img class='logo' src={assets.logo} alt="Logo" />
      </a>
      <ul class="navbar-menu">
        <a 
          href="/" 
          onClick$={() => {
            state.menu = "home";
            props.navigateTo('/'); // Update navigation
          }} 
          class={`${state.menu === "home" ? "active" : ""}`}
        >
          home
        </a>
        <a 
          href='#explore-menu' 
          onClick$={() => {
            state.menu = "menu";
            props.navigateTo('#explore-menu'); // Update navigation
          }} 
          class={`${state.menu === "menu" ? "active" : ""}`}
        >
          menu
        </a>
      </ul>
      <div class="navbar-right">
        <img src={assets.search_icon} alt="Search" />
        <a href='/cart' class='navbar-search-icon'>
          <img src={assets.basket_icon} alt="Basket" />
          <div class={getTotalCartAmount() > 0 ? "dot" : ""}></div>
        </a>
        {!token ? (
          <button onClick$={() => props.setShowLogin(true)}>sign in</button>
        ) : (
          <div class='navbar-profile'>
            <img src={assets.profile_icon} alt="Profile" />
            <ul class='navbar-profile-dropdown'>
              <li onClick$={() => props.navigateTo('/myorders')}> {/* Update navigation */}
                <img src={assets.bag_icon} alt="Orders" />
                <p>Orders</p>
              </li>
              <hr />
              <li onClick$={logout}>
                <img src={assets.logout_icon} alt="Logout" />
                <p>Logout</p>
              </li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
});

export default Navbar;
